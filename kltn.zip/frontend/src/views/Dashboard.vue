<template>
    <div>
        Xin chào thế giới
    </div>
</template>