import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Login from '../views/Login&Register/Login.vue';
import Register from '../views/Login&Register/Register.vue';
import Info from '../views/Account/Info.vue';
import Training from '../views/Account/Training.vue';
import Education from '../views/Account/Education.vue';
import Work_experience from '../views/Account/Work_experience.vue';
import Teaching_activities from '../views/Account/Teaching_activities.vue';
import Research from '../views/Account/Research.vue';
import Research_results from '../views/Account/Research_results.vue';
import ApplyStudent from '../views/DangKyNCKH/ApplyStudents.vue';
import ApplyTeacher from '../views/DangKyNCKH/ApplyTeachers.vue';
import ApplyTopicStudents from '../views/DangKyNCKH/ApplyTopicStudents.vue';
import DeTaiNCKH from '../views/DeTaiNCKH/DeTaiNCKH.vue';
import ChiTietDeTai from '../views/DeTaiNCKH/ChiTietDeTai.vue';
import DeTaiDangThucHien from '../views/DeTaiNCKH/DeTaiDangThucHien.vue';
import Introduce from '../views/Introduction/Introduction.vue';
import InfoStudents from '../views/Account/InfoStudents.vue';
import DeTaiSinhVien from '@/views/DeTaiNCKH/DeTaiSinhVien.vue'
import managerTo from './managerTo';
import managerPhong from './managerPhong';

import { useAuthStore } from '../stores/auth';

const routes = [
  ...managerTo.options.routes,
  ...managerPhong.options.routes,
  { path: '/', component: Home },
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  { path: '/introduce', component: Introduce },

  //router cho trang thông tin cá nhân
  { path: '/info', component: Info },
  { path: '/info-students', component: InfoStudents},
  { path: '/education', component: Education },
  { path: '/training', component: Training },
  { path: '/work-experience', component: Work_experience },
  { path: '/teaching-activities', component: Teaching_activities },
  { path: '/research', component: Research },
  { path: '/research-results', component: Research_results },

  //router cho trang đăng ký
  { path: '/apply-students', component: ApplyStudent },
  { path: '/apply-teachers', component: ApplyTeacher },
  { path: '/apply-topic-students', component: ApplyTopicStudents },

  // Route cho đề tài
  { path: '/de-tai-nckh', component: DeTaiNCKH },
  { path: '/chi-tiet-de-tai/:id', name: 'chi-tiet-de-tai', component: ChiTietDeTai },
  { path: '/de-tai-dang-thuc-hien', component: DeTaiDangThucHien },
  { path: '/de-tai-sinh-vien', component: DeTaiSinhVien},

];
const router = createRouter({
  history: createWebHistory(),
  routes
});

// Global guard: yêu cầu đăng nhập mới được truy cập một số trang (nếu cần)
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();

  // Nếu route có meta.requiresAuth = true mà store chưa có user => chuyển login
  if (to.meta.requiresAuth && !authStore.user) {
    next('/login');
  } else {
    next();
  }
});

export default router;
