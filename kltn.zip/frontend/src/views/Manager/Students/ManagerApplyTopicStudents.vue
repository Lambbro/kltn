<template>
<div class="container">
    <!-- Header -->
    <header class="header">
      <img src="@/assets/img/logo-hou.png" alt="Logo" class="logo"/>
      <h1>HỆ THỐNG QUẢN LÝ NGHIÊN CỨU KHOA HỌC</h1>

      <!-- Hiển thị trạng thái đăng nhập -->
      <div class="auth-buttons">
        <template v-if="isAuthenticated">
          <span>{{ storedEmail }}</span>
          <button @click="handleLogout">Đăng xuất</button>
        </template>

        <template v-else>
          <button @click="$router.push('/login')">Đăng nhập</button>
        </template>
      </div>
    </header>

    <!-- Main layout -->
    <div class="main-layout">
      <!-- Sidebar -->
      <SidebarManagerToNCKH class="sidebar" />

      <!-- Main content -->
      <div class="main-content">
        <div class="content">
          <h2>Quản lý đăng ký đề tài sinh viên</h2>

          <!-- Nút bật/tắt bộ lọc -->
          <div class="filter-search">
            <button class="filter-btn" @click="showFilter = !showFilter">
              {{ showFilter ? 'Ẩn bộ lọc' : 'Hiện bộ lọc' }}
            </button>
          </div>

          <!-- Form bộ lọc -->
          <div v-if="showFilter" class="filter-form">
            <div class="filter-row">
              <div>
                <label class="label">Tên giảng viên</label>
                <input type="text" v-model="filters.ten_gv" class="input-field" />
              </div>
              <div>
                <label class="label">Tên sinh viên</label>
                <input type="text" v-model="filters.ten_sv" class="input-field" />
              </div>
              <div>
                <label class="label">Tên đề tài</label>
                <input type="text" v-model="filters.ten_de_tai" class="input-field" />
              </div>
              <div>
                <label class="label">Đợt thực hiện</label>
                <input type="number" v-model="filters.dot_thuc_hien" class="input-field" />
              </div>
            </div>
          </div>

          <!-- Thông báo trạng thái -->
          <p v-if="loading" class="loading-text">Đang tải dữ liệu...</p>
          <p v-else-if="error" class="error-text">{{ error }}</p>

          <!-- Bảng danh sách đề tài -->
          <div v-if="!loading && !error" class="table-container">
            <table class="topic-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Mã giảng viên</th>
                  <th>Tên giảng viên</th>
                  <th>Thành viên</th>
                  <th>Tên đề tài</th>
                  <th>Đợt thực hiện</th>
                  <th>Trạng thái</th>
                  <th>Hành động</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(topic, index) in filteredTopics" :key="topic.ma_nhom">
                  <td>{{ index + 1 }}</td>
                  <td>{{ topic.ma_gv }}</td>
                  <td>{{ topic.ten_gv }}</td>
                  <td>
                    <ul>
                      <li v-for="sv in topic.thanh_vien" :key="sv.ma_sv">
                        {{ sv.ma_sv }} - {{ sv.ten_sv }}
                      </li>
                      <li v-if="!topic.thanh_vien?.length">Không có</li>
                    </ul>
                  </td>
                  <td>{{ topic.ten_de_tai }}</td>
                  <td>{{ topic.dot_thuc_hien }}</td>
                  <td>{{ formatTrangThai(topic.trang_thai) }}</td>
                  <td>
                    <button class="action-btn" @click="handleView(topic)">Xem</button>
                    <button class="action-btn" @click="handleEdit(topic)">Sửa</button>
                    <button class="action-btn" @click="handleDelete(topic.ma_nhom)">Xóa</button>
                  </td>
                </tr>
                <tr v-if="filteredTopics.length === 0">
                  <td colspan="6">Không có đề tài nào được đăng ký</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
      <Footer class="footer-content" />
    </footer>

    <!-- Modal Form -->
    <div v-if="showModal" class="modal-overlay" @click="closeModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>{{ isEditing ? 'Chỉnh sửa đề tài' : 'Chi tiết đề tài' }}</h3>
          <button class="close-btn" @click="closeModal">×</button>
        </div>
        
        <form class="modal-form" @submit.prevent="handleSubmit">
          <div class="form-group">
            <label>Mã giảng viên:</label>
            <input type="text" v-model="currentTopic.ma_gv" :disabled="!isEditing" />
          </div>
          
          <div class="form-group">
            <label>Tên giảng viên:</label>
            <input type="text" v-model="currentTopic.ten_gv" :disabled="!isEditing" />
          </div>
          
          <div class="form-group">
            <label>Tên đề tài:</label>
            <input type="text" v-model="currentTopic.ten_de_tai" :disabled="!isEditing" />
          </div>
          
          <div class="form-group">
            <label>Đợt thực hiện:</label>
            <input type="number" v-model="currentTopic.dot_thuc_hien" :disabled="!isEditing" />
          </div>
          
          <div class="form-group">
            <label>Trạng thái:</label>
            <select v-model="currentTopic.trang_thai" :disabled="!isEditing">
              <option value="0">Chưa duyệt</option>
              <option value="1">Đã đăng ký</option>
              <option value="2">Đã duyệt</option>
            </select>
          </div>
          
          <div class="form-group">
            <label>Thành viên:</label>
            <div class="member-list">
              <div v-for="(member, index) in currentTopic.thanh_vien" :key="index" class="member-item">
                <input type="text" v-model="member.ma_sv" :disabled="!isEditing" placeholder="Mã sinh viên" />
                <input type="text" v-model="member.ten_sv" :disabled="!isEditing" placeholder="Tên sinh viên" />
              </div>
            </div>
          </div>
          
          <div class="form-actions" v-if="isEditing">
            <button type="submit" class="save-btn">Lưu</button>
            <button type="button" class="cancel-btn" @click="closeModal">Hủy</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import api from '@/config/api';
import SidebarManagerToNCKH from '@/components/SidebarManagerToNCKH.vue';
import Footer from '@/components/Footer.vue';

const router = useRouter();
const authStore = useAuthStore();
const { isAuthenticated, storedEmail, logout } = authStore;

// Trạng thái dữ liệu
const topicList = ref([]);
const loading = ref(false);
const error = ref('');

// Thêm các ref mới
const showModal = ref(false);
const isEditing = ref(false);
const currentTopic = ref({
  ma_gv: '',
  ten_gv: '',
  ten_de_tai: '',
  dot_thuc_hien: new Date().getFullYear(),
  trang_thai: 0,
  thanh_vien: []
});

// Thêm ref cho bộ lọc
const filters = ref({
  ten_gv: '',
  ten_sv: '',
  ten_de_tai: '',
  dot_thuc_hien: ''
});

// Thêm ref cho trạng thái hiển thị bộ lọc
const showFilter = ref(false);

// Kiểm tra đăng nhập và lấy dữ liệu khi mount
onMounted(() => {
  authStore.loadUserFromStorage();
  fetchTopicList();
});

// Hàm đăng xuất
const handleLogout = () => {
  logout();
  router.push('/login');
};

// Lấy danh sách đề tài từ API
async function fetchTopicList() {
  try {
    loading.value = true;
    error.value = '';
    const response = await api.get('gv/nhomnckh');
    const data = response.data;

    if (!Array.isArray(data)) {
      throw new Error('Dữ liệu đề tài không hợp lệ');
    }

    topicList.value = data.map((item) => ({
      ma_nhom: item.ma_nhom,
      ma_gv: item.ma_gv || '',
      ten_gv: item.ten_gv || 'Không xác định',
      dot_thuc_hien: item.dot_thuc_hien || new Date().getFullYear(),
      ten_de_tai: item.ten_de_tai || 'Không xác định',
      trang_thai: item.trang_thai || 0,
      thanh_vien: Array.isArray(item.thanh_vien)
        ? item.thanh_vien.map((sv) => ({
            ma_sv: sv.ma_sv || '',
            ten_sv: sv.ten_sv || '',
          }))
        : [],
    }));
  } catch (err) {
    let errorMessage = 'Không thể tải danh sách đề tài';
    if (err.response) {
      console.error('Mã lỗi HTTP:', err.response.status);
      if (err.response.status === 401) {
        errorMessage = 'Phiên đăng nhập hết hạn';
        authStore.logout();
        router.push('/login');
      } else if (err.response.status === 403) {
        errorMessage = 'Bạn không có quyền truy cập';
      } else if (err.response.status === 404) {
        errorMessage = 'Danh sách đề tài trống';
        topicList.value = [];
      }
    }
    error.value = errorMessage;
    topicList.value = [];
    console.error('Lỗi khi lấy danh sách đề tài:', err);
  } finally {
    loading.value = false;
  }
}

// Định dạng trạng thái
function formatTrangThai(trang_thai) {
  switch (trang_thai) {
    case 1:
      return 'Đã đăng ký';
    case 2:
      return 'Đã duyệt';
    case 0:
      return 'Chưa duyệt';
    default:
      return 'Không xác định';
  }
}

// Cập nhật hàm handleView
function handleView(topic) {
  isEditing.value = false;
  currentTopic.value = { ...topic };
  showModal.value = true;
}

// Cập nhật hàm handleEdit
function handleEdit(topic) {
  isEditing.value = true;
  currentTopic.value = { ...topic };
  showModal.value = true;
}

// Thêm hàm closeModal
function closeModal() {
  showModal.value = false;
  currentTopic.value = {
    ma_gv: '',
    ten_gv: '',
    ten_de_tai: '',
    dot_thuc_hien: new Date().getFullYear(),
    trang_thai: 0,
    thanh_vien: []
  };
}

// Thêm hàm handleSubmit
async function handleSubmit() {
  try {
    const response = await api.put(`gv/nhomnckh/${currentTopic.value.ma_nhom}`, currentTopic.value);
    if (response.data) {
      // Cập nhật lại danh sách
      await fetchTopicList();
      closeModal();
    }
  } catch (err) {
    console.error('Lỗi khi cập nhật đề tài:', err);
    error.value = 'Không thể cập nhật đề tài';
  }
}

function handleDelete(ma_nhom) {
  if (window.confirm('Bạn có chắc chắn muốn xóa đề tài này?')) {
    // TODO: Xử lý xóa
    console.log('Xóa:', ma_nhom);
  }
}

// Thêm computed property cho danh sách đã lọc
const filteredTopics = computed(() => {
  return topicList.value.filter(topic => {
    const matchesGV = !filters.value.ten_gv || 
      topic.ten_gv.toLowerCase().includes(filters.value.ten_gv.toLowerCase());
    
    const matchesSV = !filters.value.ten_sv || 
      topic.thanh_vien.some(sv => 
        sv.ten_sv.toLowerCase().includes(filters.value.ten_sv.toLowerCase())
      );
    
    const matchesTopic = !filters.value.ten_de_tai || 
      topic.ten_de_tai.toLowerCase().includes(filters.value.ten_de_tai.toLowerCase());
    
    const matchesDot = !filters.value.dot_thuc_hien || 
      topic.dot_thuc_hien.toString().includes(filters.value.dot_thuc_hien.toString());
    
    return matchesGV && matchesSV && matchesTopic && matchesDot;
  });
});
</script>

<style scoped>
/* Container */
.container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  overflow-y: auto;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
}

.container::-webkit-scrollbar {
  width: 6px;
}

.container::-webkit-scrollbar-track {
  background: #e2e8f0;
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #0082c6, #0069a3);
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #0069a3, #005a8c);
}

/* Header */
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 80px;
  z-index: 1000;
  padding: 10px 20px 10px 70px;
  box-sizing: border-box;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.logo {
  width: 50px;
  margin-right: 2rem;
  margin-top: 2rem;
  transition: all 0.3s ease;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
}

.logo:hover {
  transform: scale(1.05) rotate(5deg);
  filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.2));
}

.header h1 {
  font-size: 1.2rem;
  margin: 0;
  text-align: center;
  color: #0082c6;
}

.auth-buttons {
  display: flex;
  gap: 0.8rem;
  align-items: center;
}

.auth-buttons span {
  font-size: 0.9rem;
  color: #4b5563;
  font-weight: 500;
}

.auth-buttons button {
  padding: 0.5rem 1rem;
  background: linear-gradient(135deg, #0082c6, #0069a3);
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 130, 198, 0.2);
}

.auth-buttons button:hover {
  background: linear-gradient(135deg, #0069a3, #005a8c);
  transform: translateY(-2px);
  box-shadow: 0 4px 6px rgba(0, 130, 198, 0.3);
}

/* Main layout */
.main-layout {
  display: flex;
  margin-top: 100px;
  min-height: calc(100vh - 100px - 100px);
  gap: 20px;
}

/* Sidebar */
.sidebar {
  width: 220px;
  background: #0082c6;
  position: fixed;
  top: 80px;
  left: 0;
  height: calc(100vh - 100px);
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
  transition: left 0.3s ease;
  z-index: 1000;
}

/* Main Content */
.main-content {
  flex: 1;
  padding: 20px;
  box-sizing: border-box;
  background: #f4f7fa;
  transition: margin-left 0.3s ease;
  margin-left: 240px;
  margin-top: 20px;
}

/* Content */
.content {
  background-color: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  border: 1px solid rgba(226, 232, 240, 0.8);
}

.content:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.content h2 {
  font-size: 1.5rem;
  background: linear-gradient(135deg, #0082c6, #0069a3);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 1.5rem;
  font-weight: 700;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  letter-spacing: 0.5px;
}

/* Status Messages */
.loading-text {
  color: #4b5563;
  font-size: 1.1rem;
  text-align: center;
  padding: 20px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 8px;
  backdrop-filter: blur(5px);
}

.error-text {
  color: #ef4444;
  font-size: 1.1rem;
  text-align: center;
  padding: 20px;
  background: rgba(254, 226, 226, 0.8);
  border-radius: 8px;
  margin: 10px 0;
  backdrop-filter: blur(5px);
  border: 1px solid rgba(239, 68, 68, 0.2);
}

/* Table */
.table-container {
  background-color: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  overflow-x: auto;
  transition: all 0.3s ease;
  border: 1px solid rgba(226, 232, 240, 0.8);
}

.table-container:hover {
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.topic-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin-top: 1rem;
}

.topic-table th,
.topic-table td {
  padding: 15px;
  text-align: left;
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
}

.topic-table th {
  background: linear-gradient(135deg, #0082c6, #0069a3);
  color: white;
  font-weight: 600;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  position: sticky;
  top: 0;
  z-index: 1;
}

.topic-table td {
  background: rgba(255, 255, 255, 0.8);
  font-size: 14px;
  color: #4b5563;
  transition: all 0.3s ease;
}

.topic-table tr:hover td {
  background: rgba(248, 250, 252, 0.8);
  transform: scale(1.01);
}

.topic-table ul {
  margin: 0;
  padding-left: 20px;
}

.topic-table ul li {
  font-size: 14px;
  margin-bottom: 5px;
  color: #4b5563;
  transition: all 0.3s ease;
}

.topic-table ul li:hover {
  color: #0082c6;
  transform: translateX(5px);
}

.action-btn {
  background-color: #0082c6;
  color: white;
  padding: 8px 16px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
  margin-right: 5px;
}

.action-btn:hover {
  background-color: #0069a3;
}

/* Footer */
.footer {
  background: #0082c6;
  color: white;
  padding: 1rem;
  text-align: center;
  height: 100px;
}

/* Responsive */
@media (max-width: 1024px) {
  .main-content {
    margin-left: 220px;
    padding: 20px;
  }

  .sidebar {
    width: 200px;
  }
}

@media (max-width: 768px) {
  .main-layout {
    margin-top: 80px;
  }

  .sidebar {
    top: 80px;
    width: 200px;
    left: -200px;
  }

  .sidebar-open {
    left: 0;
  }

  .main-content {
    margin-left: 0;
    margin-top: 20px;
    padding: 15px;
  }
}

@media (max-width: 480px) {
  .main-layout {
    margin-top: 80px;
  }

  .sidebar {
    top: 80px;
    width: 180px;
    left: -180px;
  }

  .sidebar-open {
    left: 0;
  }

  .main-content {
    padding: 10px;
  }
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #e2e8f0;
}

.modal-header h3 {
  margin: 0;
  color: #0082c6;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #6b7280;
}

.modal-form {
  padding: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  color: #4b5563;
  font-weight: 500;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #d1dbe3;
  border-radius: 4px;
  font-size: 14px;
}

.form-group input:disabled,
.form-group select:disabled {
  background-color: #f3f4f6;
  cursor: not-allowed;
}

.member-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.member-item {
  display: flex;
  gap: 10px;
}

.member-item input {
  flex: 1;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}

.save-btn,
.cancel-btn {
  padding: 8px 16px;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  border: none;
}

.save-btn {
  background: #0082c6;
  color: white;
}

.cancel-btn {
  background: #e2e8f0;
  color: #4b5563;
}

.save-btn:hover {
  background: #0069a3;
}

.cancel-btn:hover {
  background: #d1dbe3;
}

/* Filter search */
.filter-search {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
}

.filter-btn {
  background-color: #0082c6;
  color: white;
  padding: 10px 24px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.filter-btn:hover {
  background-color: #0069a3;
  transform: translateY(-1px);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Filter form */
.filter-form {
  border: 1px solid #e2e8f0;
  padding: 20px;
  border-radius: 12px;
  background: white;
  margin-bottom: 24px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.filter-row > div {
  flex: 1 1 250px;
}

.filter-row label.label {
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #1e293b;
  font-size: 0.95rem;
}

.filter-row input.input-field {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 0.95rem;
  background-color: #f8fafc;
  transition: all 0.3s ease;
}

.filter-row input.input-field:focus {
  border-color: #0082c6;
  box-shadow: 0 0 0 3px rgba(0, 130, 198, 0.1);
  background-color: white;
  outline: none;
}

/* Responsive Filter */
@media (max-width: 768px) {
  .filter-row {
    flex-direction: column;
    gap: 16px;
  }

  .filter-row > div {
    flex: 1 1 auto;
  }
}

@media (max-width: 480px) {
  .filter-btn {
    width: 100%;
    padding: 8px 16px;
  }

  .filter-form {
    padding: 16px;
  }

  .filter-row label.label {
    font-size: 0.9rem;
  }

  .filter-row input.input-field {
    padding: 8px;
    font-size: 0.9rem;
  }
}
</style>