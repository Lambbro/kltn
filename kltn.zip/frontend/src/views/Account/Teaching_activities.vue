<template>
  <div class="container">
    <!-- Overlay khi sidebar mở trên mobile -->
    <div v-if="isSidebarOpen && isMobile" class="overlay" @click="toggleSidebar"></div>

    <!-- Nút toggle sidebar -->
    <button class="toggle-sidebar" @click="toggleSidebar">
      ☰
    </button>

    <!-- Sử dụng component SidebarInfo -->
    <SidebarInfo :is-open="isSidebarOpen" @toggle="toggleSidebar" />

    <!-- Nội dung chính -->
    <div class="main-content" :class="{ 'main-content-shifted': isSidebarOpen && !isMobile }">
      <div class="content">
        <!-- Thông báo trạng thái -->
        <p v-if="loading" class="loading-text">Đang tải dữ liệu...</p>
        <p v-else-if="error" class="error-text">{{ error }}</p>

        <!-- Cột nhập liệu Hoạt động giảng dạy -->
        <div v-else class="column">
          <div class="hoatDongGiangDay">
            <p class="section-title">Thêm thông tin hoạt động giảng dạy</p>
            <div class="info-row">
              <p class="sub-label">Tên môn học/bộ phận</p>
              <input
                type="text"
                v-model="newTeachingEntry.tenMonHoc"
                placeholder="Ví dụ: Tin học đại cương"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Chuyên ngành</p>
              <input
                type="text"
                v-model="newTeachingEntry.chuyenNganh"
                placeholder="Ví dụ: Lược KT, QTKD, Kế toán"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Trình độ</p>
              <select v-model="newTeachingEntry.trinhDo" class="input-field">
                <option value="ĐH">ĐH</option>
                <option value="ThS">ThS</option>
                <option value="TS">TS</option>
              </select>
            </div>
            <div class="info-row">
              <p class="sub-label">Số năm</p>
              <input
                type="text"
                v-model="newTeachingEntry.soNam"
                placeholder="Ví dụ: 19"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Nơi giảng dạy</p>
              <input
                type="text"
                v-model="newTeachingEntry.noiGiangDay"
                placeholder="Ví dụ: Trường ĐH Mở Hà Nội"
                class="input-field"
              />
            </div>
            <button
              @click="addTeachingEntry"
              class="save-button"
              :disabled="saving"
            >
              {{ saving ? 'Đang lưu...' : 'Cập nhật' }}
            </button>
          </div>
        </div>

        <!-- Cột bảng hiển thị Hoạt động giảng dạy -->
        <div class="column">
          <div class="table-container">
            <p class="section-title">Tham gia hoạt động giảng dạy</p>
            <table>
              <thead>
                <tr>
                  <th>Tên môn học/bộ phận</th>
                  <th>Chuyên ngành</th>
                  <th>Trình độ</th>
                  <th>Số năm</th>
                  <th>Nơi giảng dạy</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(entry, index) in teachingEntries" :key="index">
                  <td>{{ entry.tenMonHoc }}</td>
                  <td>{{ entry.chuyenNganh }}</td>
                  <td>{{ entry.trinhDo }}</td>
                  <td>{{ entry.soNam }}</td>
                  <td>{{ entry.noiGiangDay }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Cột nhập liệu Hoạt động khoa học -->
        <div class="column">
          <div class="hoatDongKhoaHoc">
            <p class="section-title">Thêm thông tin hoạt động khoa học</p>
            <div class="info-row">
              <p class="sub-label">Tên đề tài</p>
              <input
                type="text"
                v-model="newResearchEntry.tenDeTai"
                placeholder="Ví dụ: Nghiên cứu AI"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Vai trò hướng dẫn</p>
              <input
                type="text"
                v-model="newResearchEntry.vaiTroHuongDan"
                placeholder="Ví dụ: Chủ nhiệm"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Tên người học</p>
              <input
                type="text"
                v-model="newResearchEntry.tenNguoiHoc"
                placeholder="Ví dụ: Nguyễn Văn A"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Cơ sở đào tạo</p>
              <input
                type="text"
                v-model="newResearchEntry.coSoDaoTao"
                placeholder="Ví dụ: Trường ĐH Mở Hà Nội"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Học vị</p>
              <select v-model="newResearchEntry.hocVi" class="input-field">
                <option value="ĐH">ĐH</option>
                <option value="ThS">ThS</option>
                <option value="TS">TS</option>
              </select>
            </div>
            <button
              @click="addResearchEntry"
              class="save-button"
              :disabled="saving"
            >
              {{ saving ? 'Đang lưu...' : 'Cập nhật' }}
            </button>
          </div>
        </div>

        <!-- Cột bảng hiển thị Hoạt động khoa học -->
        <div class="column">
          <div class="table-container">
            <p class="section-title">Hoạt động khoa học</p>
            <table>
              <thead>
                <tr>
                  <th>Tên đề tài</th>
                  <th>Vai trò hướng dẫn</th>
                  <th>Tên người học</th>
                  <th>Cơ sở đào tạo</th>
                  <th>Học vị</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(entry, index) in researchEntries" :key="index">
                  <td>{{ entry.tenDeTai }}</td>
                  <td>{{ entry.vaiTroHuongDan }}</td>
                  <td>{{ entry.tenNguoiHoc }}</td>
                  <td>{{ entry.coSoDaoTao }}</td>
                  <td>{{ entry.hocVi }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <router-view></router-view>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import SidebarInfo from '../../components/SidebarInfo.vue';
import api from '@/config/api';

// Trạng thái sidebar
const isSidebarOpen = ref(true); // Mặc định mở
const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value;
};

// Kiểm tra màn hình mobile
const isMobile = ref(window.innerWidth <= 768);
window.addEventListener('resize', () => {
  isMobile.value = window.innerWidth <= 768;
  if (isMobile.value && isSidebarOpen.value) {
    isSidebarOpen.value = false; // Đóng sidebar khi resize về mobile
  }
});

// Trạng thái dữ liệu
const loading = ref(false);
const saving = ref(false);
const error = ref('');

// Dữ liệu ban đầu của bảng Hoạt động giảng dạy
const teachingEntries = ref([]);

// Dữ liệu cho form nhập liệu Hoạt động giảng dạy
const newTeachingEntry = ref({
  tenMonHoc: '',
  chuyenNganh: '',
  trinhDo: '',
  soNam: '',
  noiGiangDay: '',
});

// Dữ liệu ban đầu của bảng Hoạt động khoa học
const researchEntries = ref([]);

// Dữ liệu cho form nhập liệu Hoạt động khoa học
const newResearchEntry = ref({
  tenDeTai: '',
  vaiTroHuongDan: '',
  tenNguoiHoc: '',
  coSoDaoTao: '',
  hocVi: '',
});

// Khởi tạo authStore và router
const authStore = useAuthStore();
const router = useRouter();

// Lấy dữ liệu khi component được mount
onMounted(() => {
  authStore.loadUserFromStorage();
  fetchTeachingEntries();
  fetchResearchEntries();
});

// Lấy danh sách Hoạt động giảng dạy từ API
async function fetchTeachingEntries() {
  try {
    loading.value = true;
    error.value = '';

    if (!authStore.user?.email) {
      throw new Error('Vui lòng đăng nhập để xem thông tin');
    }

    const ma_gv = authStore.user.email.split('@')[0];
    const response = await api.get(`phongkhdn/gv/${ma_gv}/teaching-activities/`);
    teachingEntries.value = response.data || [];
  } catch (err) {
    handleError(err, 'Không thể tải thông tin hoạt động giảng dạy');
  } finally {
    loading.value = false;
  }
}

// Lấy danh sách Hoạt động khoa học từ API
async function fetchResearchEntries() {
  try {
    loading.value = true;
    error.value = '';

    if (!authStore.user?.email) {
      throw new Error('Vui lòng đăng nhập để xem thông tin');
    }

    const ma_gv = authStore.user.email.split('@')[0];
    const response = await api.get(`phongkhdn/gv/${ma_gv}/research-activities/`);
    researchEntries.value = response.data || [];
  } catch (err) {
    handleError(err, 'Không thể tải thông tin hoạt động khoa học');
  } finally {
    loading.value = false;
  }
}

// Hàm thêm mục mới vào bảng Hoạt động giảng dạy
async function addTeachingEntry() {
  if (
    !newTeachingEntry.value.tenMonHoc ||
    !newTeachingEntry.value.chuyenNganh ||
    !newTeachingEntry.value.trinhDo ||
    !newTeachingEntry.value.soNam ||
    !newTeachingEntry.value.noiGiangDay
  ) {
    alert('Vui lòng điền đầy đủ thông tin hoạt động giảng dạy!');
    return;
  }

  try {
    saving.value = true;
    error.value = '';

    const ma_gv = authStore.user.email.split('@')[0];
    const payload = { ...newTeachingEntry.value, ma_gv };
    await api.post(`phongkhdn/gv/${ma_gv}/teaching-activities/`, payload);

    // Thêm vào danh sách hiển thị
    teachingEntries.value.push({ ...newTeachingEntry.value });

    // Reset form
    newTeachingEntry.value = {
      tenMonHoc: '',
      chuyenNganh: '',
      trinhDo: '',
      soNam: '',
      noiGiangDay: '',
    };

    alert('Thêm hoạt động giảng dạy thành công!');
  } catch (err) {
    handleError(err, 'Không thể thêm hoạt động giảng dạy');
  } finally {
    saving.value = false;
  }
}

// Hàm thêm mục mới vào bảng Hoạt động khoa học
async function addResearchEntry() {
  if (
    !newResearchEntry.value.tenDeTai ||
    !newResearchEntry.value.vaiTroHuongDan ||
    !newResearchEntry.value.tenNguoiHoc ||
    !newResearchEntry.value.coSoDaoTao ||
    !newResearchEntry.value.hocVi
  ) {
    alert('Vui lòng điền đầy đủ thông tin hoạt động khoa học!');
    return;
  }

  try {
    saving.value = true;
    error.value = '';

    const ma_gv = authStore.user.email.split('@')[0];
    const payload = { ...newResearchEntry.value, ma_gv };
    await api.post(`phongkhdn/gv/${ma_gv}/research-activities/`, payload);

    // Thêm vào danh sách hiển thị
    researchEntries.value.push({ ...newResearchEntry.value });

    // Reset form
    newResearchEntry.value = {
      tenDeTai: '',
      vaiTroHuongDan: '',
      tenNguoiHoc: '',
      coSoDaoTao: '',
      hocVi: '',
    };

    alert('Thêm hoạt động khoa học thành công!');
  } catch (err) {
    handleError(err, 'Không thể thêm hoạt động khoa học');
  } finally {
    saving.value = false;
  }
}

// Hàm xử lý lỗi chung
function handleError(err, defaultMsg) {
  let errorMsg = defaultMsg;
  if (err.response) {
    console.error('Mã lỗi HTTP:', err.response.status);
    console.error('Chi tiết lỗi:', err.response.data);
    if (err.response.status === 401) {
      errorMsg = 'Phiên đăng nhập hết hạn';
      authStore.logout();
      router.push('/login');
    } else if (err.response.status === 403) {
      errorMsg = 'Bạn không có quyền truy cập thông tin này';
    } else if (err.response.status === 404) {
      errorMsg = 'Không tìm thấy thông tin';
    } else if (err.response.status === 500) {
      errorMsg = 'Lỗi server, vui lòng thử lại sau';
    } else {
      errorMsg = err.response.data.detail || defaultMsg;
    }
  } else if (err.request) {
    errorMsg = 'Không thể kết nối đến server';
  } else {
    errorMsg = err.message || defaultMsg;
  }
  error.value = errorMsg;
  console.error('Lỗi:', err);
}
</script>

<style scoped>
/* Container */
.container {
  width: 100%;
  max-width: 1280px; /* Giới hạn chiều rộng để phù hợp với laptop */
  height: 100vh;
  display: flex;
  flex-direction: column;
  margin: 0 auto; /* Căn giữa */
  position: relative;
}


/* Overlay cho mobile */
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
}

/* Toggle Sidebar Button */
.toggle-sidebar {
  position: fixed;
  top: 10px;
  left: 10px;
  z-index: 1100;
  background-color: #2563eb;
  color: white;
  border: none;
  padding: 8px;
  border-radius: 6px;
  cursor: pointer;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, transform 0.3s;
}

.toggle-sidebar:hover {
  background-color: #1d4ed8;
  transform: scale(1.05);
}

/* Main Content */
.main-content {
  flex: 1;
  width: 120%;
  height: calc(100vh - 60px); /* Trừ chiều cao header */
  padding: 15px;
  box-sizing: border-box;
  overflow-y: auto;
  background: linear-gradient(to bottom right, #e6eef5, #f4f7fa);
}

/* Scrollbar tùy chỉnh */
.main-content::-webkit-scrollbar {
  width: 3px;
}

.main-content::-webkit-scrollbar-track {
  background: #e6eef5;
  border-radius: 10px;
}

.main-content::-webkit-scrollbar-thumb {
  background: #1e88e5;
  border-radius: 10px;
}

.main-content::-webkit-scrollbar-thumb:hover {
  background: #1565c0;
}

/* Content Grid */
.content {
  display: grid;
  grid-template-columns: repeat(2, 1fr); /* Hai cột đều nhau */
  gap: 20px; /* Giảm khoảng cách */
  width: 100%;
}

/* Responsive */
@media (max-width: 768px) {
  .content {
    grid-template-columns: 1fr; /* Một cột trên mobile */
  }

  .main-content {
    width: 100%;
    margin-left: 0;
    padding: 15px 8px;
    margin-top: 50px;
    height: calc(100vh - 50px);
  }

  .main-content-shifted {
    margin-left: 0;
    width: 100%;
  }
}

/* Column */
.column {
  background-color: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
}

.column:hover {
  transform: translateY(-2px);
}

/* Status Messages */
.loading-text {
  color: #4b5563;
  text-align: center;
  margin: 20px 0;
}

.error-text {
  color: #ef4444;
  text-align: center;
  margin: 20px 0;
}

/* Section Title */
.section-title {
  font-weight: 600;
  color: #1a3c5e;
  font-size: 16px;
  margin-bottom: 10px;
}

/* Form nhập liệu */
.hoatDongGiangDay,
.hoatDongKhoaHoc {
  margin-top: 15px;
}

.info-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 4px;
  padding: 4px;
}

.sub-label {
  font-weight: 600;
  color: #1a3c5e;
  font-size: 14px;
  width: 35%;
}

.input-field {
  width: 65%;
  padding: 8px;
  border: 1px solid #d1dbe3;
  border-radius: 6px;
  font-size: 14px;
  background-color: #f9fafb;
  transition: border-color 0.3s, box-shadow 0.3s, background-color 0.3s;
}

.input-field:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
  background-color: white;
  outline: none;
}

.input-field::placeholder {
  color: #a0aec0;
  font-style: italic;
}

/* Save Button */
.save-button {
  margin-top: 16px;
  background-color: #2563eb;
  color: white;
  padding: 8px 20px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s;
}

.save-button:hover {
  background-color: #1d4ed8;
}

.save-button:disabled {
  background-color: #93c5fd;
  cursor: not-allowed;
}

/* Bảng hiển thị */
.table-container {
  width: 100%;
  overflow-x: hidden; /* Không cần scroll-x */
}

table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin-top: 10px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

th,
td {
  padding: 10px 12px;
  text-align: left;
  border-bottom: 1px solid #e2e8f0;
  font-size: 13px;
}

th {
  background: #2563eb;
  color: white;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 0.5px;
}

td {
  background: #fff;
  color: #2d3748;
}

tr:last-child td {
  border-bottom: none;
}

tr:hover td {
  background: #f5faff;
}
</style>