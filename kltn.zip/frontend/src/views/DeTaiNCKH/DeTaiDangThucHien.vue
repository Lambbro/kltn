<template>
    <div class="container">
        <header class="header">
            <img src="@/assets/img/logo-hou.png" alt="Logo" class="logo"/>
            <div class="button-group">
                <button class="active" @click="$router.push(`/de-tai-nckh`)">Tổng hợp đề tài</button>
                <button class="active" @click="$router.push(`/de-tai-dang-thuc-hien`)">Đề tài đang thực hiện</button>
            </div>
        </header>

        <div class="main-layout">
            <SidebarHome class="sidebar" />
            <div class="main-content">
                <!-- Vùng chứa nút Bộ lọc và ô tìm kiếm -->
                <h2 style="color:red">Đây là trang đề tài m đang thực hiện, m có làm chó đâu mà coiiiiiiii, cút ra ngoài </h2>
                <h2>Tên đề tài </h2>
                
            </div>
        </div>
    </div>
</template>

<script setup>
import SidebarHome from '@/components/SidebarHome.vue';
import { ref, computed } from 'vue';

</script>
<style scoped>
.container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  overflow-y: auto;
  max-width: 1280px;
}

.container::-webkit-scrollbar {
  width: 5px;
}

.container::-webkit-scrollbar-track {
  background: #e6eef5;
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb {
  background: #1e88e5;
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb:hover {
  background: #1565c0;
}

/* Header */
.header {
  display: flex;
  align-items: center;
  justify-content: flex-start; /* Căn trái logo và button group */
  background: #2563eb;
  border-bottom: 1px solid #ccc;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  height: 80px;
  padding: 10px 40px;
  box-sizing: border-box;
}

.logo {
  width: 50px;
  margin-right: 1rem;
}

.button-group {
  display: flex;
  gap: 20px;
  align-items: center;
  margin-left: 120px; /* Khoảng cách từ logo */
}

.button-group button {
  padding: 10px 15px;
  border: none;
  background: #e0e0e0;
  cursor: pointer;
  border-radius: 5px;
  color: #333;
  font-size: 14px;
}

.button-group button.active,
.button-group button:hover {
  background: #1e88e5;
  color: white;
}

.sidebar-toggle {
  display: none;
  background: #2563eb;
  color: white;
  border: none;
  padding: 0.5rem 0.8rem;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 5px;
}

/* Main layout */
.main-layout {
  display: flex;
  margin-top: 80px; /* Khoảng cách với header */
  min-height: calc(100vh - 80px);
}

/* Sidebar */
.sidebar {
  width: 220px;
  background: #2563eb;
  position: fixed;
  top: 80px;
  left: 0;
  height: calc(100vh - 80px);
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
  transition: left 0.3s ease;
  z-index: 999;
}

/* Main content */
.main-content {
  flex: 1;
  padding: 20px 40px; /* Padding 40px trái/phải */
  background: #f4f4f4;
  margin-left: 220px; /* Tránh sidebar */
  width: calc(100% - 220px); /* Chiếm toàn bộ chiều rộng trừ sidebar */
  box-sizing: border-box;
}

/* Responsive */

/* Tablet (≤1024px) */
@media (max-width: 1024px) {
  .header {
    padding: 10px 20px;
  }

  .main-content {
    margin-left: 200px; /* Sidebar thu gọn */
    width: calc(100% - 200px); /* Chiếm toàn bộ trừ sidebar */
    padding: 20px;
  }

  .sidebar {
    width: 200px;
  }

  .button-group {
    margin-left: 15px;
    gap: 15px;
  }

  .button-group button {
    padding: 8px 12px;
    font-size: 13px;
  }
}

/* Mobile (≤768px) */
@media (max-width: 768px) {
  .header {
    flex-wrap: wrap;
    padding: 10px 15px;
    position: fixed;
    top: 0;
  }

  .sidebar-toggle {
    display: block;
    position: absolute;
    left: 15px;
    top: 15px;
  }

  .logo {
    margin-left: 50px; /* Đẩy logo sang phải để tránh nút toggle */
    order: 1;
  }

  .button-group {
    order: 2;
    width: 100%;
    justify-content: flex-start; /* Căn trái */
    gap: 10px;
    margin-top: 10px;
    margin-left: 0;
  }

  .main-layout {
    flex-direction: column;
    margin-top: 120px; /* Header cao hơn do wrap */
  }

  .sidebar {
    width: 200px;
    left: -200px;
    top: 0;
    height: 100vh;
  }

  .sidebar-open {
    left: 0;
  }

  .main-content {
    margin-left: 0;
    width: 100%; /* Chiếm toàn bộ chiều rộng */
    padding: 15px;
  }
}

/* Small Mobile (≤480px) */
@media (max-width: 480px) {
  .header {
    padding: 10px;
  }

  .logo {
    width: 40px;
    margin-left: 50px;
  }

  .button-group {
    flex-direction: column;
    gap: 5px;
    align-items: flex-start; /* Căn trái */
  }

  .button-group button {
    width: 100%;
    padding: 10px;
    font-size: 12px;
  }

  .sidebar {
    width: 180px;
    left: -180px;
  }

  .sidebar-open {
    left: 0;
  }

  .main-content {
    padding: 10px;
    width: 100%;
  }
}
</style>