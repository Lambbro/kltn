<template>
  <div class="upload-container">
    <div v-if="imageUrl" class="image-preview">
      <img :src="imageUrl" alt="Image Preview" />
    </div>
    <input type="file" @change="onFileChange" accept="image/*" ref="fileInput" style="display: none;" />
    <button @click="triggerFileInput">Thay đổi ảnh</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      imageUrl: null,
    };
  },
  methods: {
    triggerFileInput() {
      this.$refs.fileInput.click();
    },
    onFileChange(event) {
      const file = event.target.files[0];
      if (file && file.type.startsWith('image/')) {
        this.imageUrl = URL.createObjectURL(file);
      }
    },
  },
};
</script>

<style>
.upload-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.image-preview {
  width: 150px; 
  height: 150px; 
  border-radius: 50%;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 2px solid #ccc;
}

.image-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

button {
  background-color: #4CAF50; /* Màu xanh lá cây */
  color: white;
  border: none;
  padding: 8px 16px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}

button:hover {
  background-color: #45a049;
}
</style>