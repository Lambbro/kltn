<template>
  <div class="container">
    <!-- Overlay khi sidebar mở trên mobile -->
    <div v-if="isSidebarOpen && isMobile" class="overlay" @click="toggleSidebar"></div>

    <!-- Nút toggle sidebar -->
    <button class="toggle-sidebar" @click="toggleSidebar">
      ☰
    </button>

    <!-- Sử dụng component SidebarInfo -->
    <SidebarInfo :is-open="isSidebarOpen" @toggle="toggleSidebar" />

    <!-- Nội dung chính -->
    <div class="main-content" :class="{ 'main-content-shifted': isSidebarOpen && !isMobile }">
      <div class="content">
        <!-- Thông báo trạng thái -->
        <p v-if="loading" class="loading-text">Đang tải dữ liệu...</p>
        <p v-else-if="error" class="error-text">{{ error }}</p>

        <!-- Cột nhập liệu Hướng nghiên cứu -->
        <div v-else class="column">
          <div class="huongNghienCuu">
            <p class="section-title">Thêm hướng nghiên cứu</p>
            <div class="info-row">
              <p class="sub-label">Hướng nghiên cứu</p>
              <div class="dropdown-wrapper">
                <input
                  v-model="searchHnc"
                  @focus="showDropdown = true"
                  @input="filterHnc"
                  placeholder="Chọn hướng nghiên cứu..."
                  class="input-field"
                />
                <div v-if="showDropdown" class="dropdown">
                  <p v-if="filteredHncList.length === 0" class="no-data-text">
                    Không tìm thấy hướng nghiên cứu
                  </p>
                  <div
                    v-for="hnc in filteredHncList"
                    :key="hnc.ma_hnc"
                    class="dropdown-item"
                    @click="selectHnc(hnc)"
                  >
                    {{ hnc.ten_hnc }}
                  </div>
                </div>
              </div>
            </div>
            <button
              @click="addResearchFieldEntry"
              class="save-button"
              :disabled="saving || !selectedHnc"
            >
              {{ saving ? 'Đang lưu...' : 'Thêm' }}
            </button>
          </div>
        </div>

        <!-- Cột hiển thị danh sách Hướng nghiên cứu -->
        <div class="column">
          <div class="list-container">
            <p class="section-title">Danh mục các hướng nghiên cứu</p>
            <p v-if="researchFields.length === 0" class="no-data-text">
              Chưa có hướng nghiên cứu nào.
            </p>
            <ol v-else>
              <li v-for="entry in researchFields" :key="entry.ma_hnc">
                {{ entry.ten_hnc }}
              </li>
            </ol>
          </div>
        </div>

        <!-- Cột nhập liệu Đề tài KHCN -->
        <div class="column">
          <div class="deTaiKHCN">
            <p class="section-title">Thêm thông tin đề tài KHCN</p>
            <div class="info-row">
              <p class="sub-label">Mã SP</p>
              <input
                type="text"
                v-model="newProjectEntry.maSp"
                placeholder="Ví dụ: SP001"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Tên SP</p>
              <input
                type="text"
                v-model="newProjectEntry.tenSp"
                placeholder="Ví dụ: Nghiên cứu AI"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Cấp cơ quan QL</p>
              <input
                type="text"
                v-model="newProjectEntry.capCoQuanQl"
                placeholder="Ví dụ: Bộ Giáo dục"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Thời gian thực hiện</p>
              <input
                type="text"
                v-model="newProjectEntry.thoiGianThucHien"
                placeholder="Ví dụ: 2022-2023"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Trạng thái</p>
              <select v-model="newProjectEntry.trangThai" class="input-field">
                <option value="Đang thực hiện">Đang thực hiện</option>
                <option value="Hoàn thành">Hoàn thành</option>
                <option value="Đã hủy">Đã hủy</option>
              </select>
            </div>
            <div class="info-row">
              <p class="sub-label">Kết quả</p>
              <input
                type="text"
                v-model="newProjectEntry.ketQua"
                placeholder="Ví dụ: Đạt"
                class="input-field"
              />
            </div>
            <div class="info-row">
              <p class="sub-label">Loại đề tài</p>
              <select v-model="newProjectEntry.loaiDeTai" class="input-field">
                <option value="Đề tài cấp bộ">Đề tài cấp bộ</option>
                <option value="Đề tài cấp trường">Đề tài cấp trường</option>
                <option value="Đề tài cấp quốc gia">Đề tài cấp quốc gia</option>
              </select>
            </div>
            <div class="info-row">
              <p class="sub-label">Tư cách tham gia</p>
              <input
                type="text"
                v-model="newProjectEntry.tuCachThamGia"
                placeholder="Ví dụ: Chủ nhiệm"
                class="input-field"
              />
            </div>
            <button @click="addProjectEntry" class="save-button" :disabled="saving">
              {{ saving ? 'Đang lưu...' : 'Cập nhật' }}
            </button>
          </div>
        </div>

        <!-- Cột bảng hiển thị Đề tài KHCN -->
        <div class="column">
          <div class="table-container">
            <p class="section-title">Đề tài KHCN</p>
            <table>
              <thead>
                <tr>
                  <th>Tên đề tài</th>
                  <th>Cấp cơ quan QL</th>
                  <th>Thời gian thực hiện</th>
                  <th>Trạng thái</th>
                  <th>Kết quả</th>
                  <th>Loại đề tài</th>
                  <th>Tư cách tham gia</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(entry, index) in projectEntries" :key="index">
                  <td>{{ entry.tenSp }}</td>
                  <td>{{ entry.capCoQuanQl }}</td>
                  <td>{{ entry.thoiGianThucHien }}</td>
                  <td>{{ entry.trangThai }}</td>
                  <td>{{ entry.ketQua }}</td>
                  <td>{{ entry.loaiDeTai }}</td>
                  <td>{{ entry.tuCachThamGia }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import SidebarInfo from '../../components/SidebarInfo.vue';
import api from '@/config/api';

// Trạng thái sidebar
const isSidebarOpen = ref(true);
const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value;
};

// Kiểm tra màn hình mobile
const isMobile = ref(window.innerWidth <= 768);
window.addEventListener('resize', () => {
  isMobile.value = window.innerWidth <= 768;
  if (isMobile.value && isSidebarOpen.value) {
    isSidebarOpen.value = false;
  }
});

// Trạng thái dữ liệu
const loading = ref(false);
const saving = ref(false);
const error = ref('');
const showDropdown = ref(false);

// Dữ liệu hướng nghiên cứu
const researchFields = ref([]); // HNC của giảng viên
const allHncList = ref([]); // Tất cả HNC
const searchHnc = ref('');
const selectedHnc = ref(null);

// Dữ liệu đề tài KHCN
const projectEntries = ref([]);
const newProjectEntry = ref({
  maSp: '',
  tenSp: '',
  capCoQuanQl: '',
  thoiGianThucHien: '',
  trangThai: '',
  ketQua: '',
  loaiDeTai: '',
  tuCachThamGia: '',
});

// Khởi tạo authStore và router
const authStore = useAuthStore();
const router = useRouter();

// Lấy dữ liệu khi component được mount
onMounted(async () => {
  authStore.loadUserFromStorage();
  if (!authStore.user?.email) {
    router.push('/login');
    return;
  }
  await Promise.all([fetchAllHnc(), fetchResearchFields(), fetchProjectEntries()]);
});

// Lấy tất cả hướng nghiên cứu
async function fetchAllHnc() {
  try {
    const response = await api.get('get_data/hnc/');
    if (!Array.isArray(response.data)) {
      throw new Error('Dữ liệu hướng nghiên cứu không hợp lệ');
    }
    allHncList.value = response.data;
  } catch (err) {
    handleError(err, 'Không thể tải danh sách hướng nghiên cứu');
  }
}

// Lấy danh sách hướng nghiên cứu của giảng viên
async function fetchResearchFields() {
  try {
    loading.value = true;
    error.value = '';
    const ma_gv = authStore.user.email.split('@')[0];
    const response = await api.get(`get_data/hnc_by_gv/${ma_gv}/`);
    if (!Array.isArray(response.data)) {
      throw new Error('Dữ liệu hướng nghiên cứu không hợp lệ');
    }
    researchFields.value = response.data;
  } catch (err) {
    handleError(err, 'Không thể tải danh sách hướng nghiên cứu của giảng viên');
  } finally {
    loading.value = false;
  }
}

// Thêm hướng nghiên cứu mới cho giảng viên
async function addResearchFieldEntry() {
  if (!selectedHnc.value) {
    error.value = 'Vui lòng chọn một hướng nghiên cứu';
    return;
  }

  try {
    saving.value = true;
    error.value = '';
    const ma_gv = authStore.user.email.split('@')[0];
    const ma_hnc = selectedHnc.value.ma_hnc;

    // Gọi API với query string (vì backend đang nhận ma_gv và ma_hnc là query param)
    await api.post(`/gv/syll/hnc/add?ma_gv=${ma_gv}&ma_hnc=${ma_hnc}`);

    // Cập nhật danh sách
    await fetchResearchFields();

    // Reset input
    selectedHnc.value = null;
    searchHnc.value = '';
    showDropdown.value = false;
  } catch (err) {
    handleError(err, 'Không thể thêm hướng nghiên cứu');
  } finally {
    saving.value = false;
  }
}

// Lọc danh sách HNC dựa trên tìm kiếm
const filteredHncList = computed(() => {
  const query = searchHnc.value.toLowerCase();
  return allHncList.value.filter((hnc) =>
    hnc.ten_hnc.toLowerCase().includes(query)
  );
});

// Chọn một HNC từ dropdown
function selectHnc(hnc) {
  selectedHnc.value = hnc;
  searchHnc.value = hnc.ten_hnc;
  showDropdown.value = false;
}

// // Lấy danh sách đề tài KHCN
// async function fetchProjectEntries() {
//   try {
//     loading.value = true;
//     error.value = '';
//     const ma_gv = authStore.user.email.split('@')[0];
//     const response = await api.get(`phongkhdn/gv/${ma_gv}/projects/`);
//     projectEntries.value = response.data || [];
//   } catch (err) {
//     handleError(err, 'Không thể tải thông tin đề tài KHCN');
//   } finally {
//     loading.value = false;
//   }
// }

// // Thêm đề tài KHCN
// async function addProjectEntry() {
//   const { maSp, tenSp, capCoQuanQl, thoiGianThucHien, trangThai, ketQua, loaiDeTai, tuCachThamGia } = newProjectEntry.value;
//   if (!maSp || !tenSp || !capCoQuanQl || !thoiGianThucHien || !trangThai || !ketQua || !loaiDeTai || !tuCachThamGia) {
//     error.value = 'Vui lòng điền đầy đủ thông tin đề tài KHCN';
//     return;
//   }

//   try {
//     saving.value = true;
//     error.value = '';
//     const ma_gv = authStore.user.email.split('@')[0];
//     const payload = { maSp, tenSp, capCoQuanQl, thoiGianThucHien, trangThai, ketQua, loaiDeTai, tuCachThamGia, ma_gv };
//     await api.post(`phongkhdn/gv/${ma_gv}/projects/`, payload);
//     await fetchProjectEntries();
//     newProjectEntry.value = {
//       maSp: '',
//       tenSp: '',
//       capCoQuanQl: '',
//       thoiGianThucHien: '',
//       trangThai: '',
//       ketQua: '',
//       loaiDeTai: '',
//       tuCachThamGia: '',
//     };
//   } catch (err) {
//     handleError(err, 'Không thể thêm đề tài KHCN');
//   } finally {
//     saving.value = false;
//   }
// }

// // Xử lý lỗi
// function handleError(err, defaultMsg) {
//   let errorMsg = defaultMsg;
//   if (err.response) {
//     console.error('Mã lỗi HTTP:', err.response.status);
//     console.error('Chi tiết lỗi:', err.response.data);
//     if (err.response.status === 401) {
//       errorMsg = 'Phiên đăng nhập hết hạn';
//       authStore.logout();
//       router.push('/login');
//     } else if (err.response.status === 403) {
//       errorMsg = 'Bạn không có quyền truy cập';
//     } else if (err.response.status === 404) {
//       errorMsg = 'Không tìm thấy thông tin';
//     } else if (err.response.status === 500) {
//       errorMsg = 'Lỗi server, vui lòng thử lại sau';
//     } else {
//       errorMsg = err.response.data.detail || defaultMsg;
//     }
//   } else if (err.request) {
//     errorMsg = 'Không thể kết nối đến server';
//   } else {
//     errorMsg = err.message || defaultMsg;
//   }
//   error.value = errorMsg;
//   console.error('Lỗi:', err);
// }

// Đóng dropdown khi click ra ngoài
document.addEventListener('click', (event) => {
  const dropdown = document.querySelector('.dropdown-wrapper');
  if (dropdown && !dropdown.contains(event.target)) {
    showDropdown.value = false;
  }
});
</script>

<style scoped>
/* Container */
.container {
  width: 100%;
  max-width: 1280px; /* Giới hạn chiều rộng để phù hợp với laptop */
  height: 100vh;
  display: flex;
  flex-direction: column;
  margin: 0 auto; /* Căn giữa */
  position: relative;
}


/* Overlay cho mobile */
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
}

/* Toggle Sidebar Button */
.toggle-sidebar {
  position: fixed;
  top: 10px;
  left: 10px;
  z-index: 1100;
  background-color: #2563eb;
  color: white;
  border: none;
  padding: 8px;
  border-radius: 6px;
  cursor: pointer;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, transform 0.3s;
}

.toggle-sidebar:hover {
  background-color: #1d4ed8;
  transform: scale(1.05);
}

/* Main Content */
.main-content {
  flex: 1;
  width: 120%;
  height: calc(100vh - 60px); /* Trừ chiều cao header */
  padding: 15px;
  box-sizing: border-box;
  overflow-y: auto;
  background: linear-gradient(to bottom right, #e6eef5, #f4f7fa);
}

/* Scrollbar tùy chỉnh */
.main-content::-webkit-scrollbar {
  width: 3px;
}

.main-content::-webkit-scrollbar-track {
  background: #e6eef5;
  border-radius: 10px;
}

.main-content::-webkit-scrollbar-thumb {
  background: #1e88e5;
  border-radius: 10px;
}

.main-content::-webkit-scrollbar-thumb:hover {
  background: #1565c0;
}

/* Content Grid */
.content {
  display: grid;
  grid-template-columns: repeat(2, 1fr); /* Hai cột đều nhau */
  gap: 20px; /* Giảm khoảng cách */
  width: 100%;
}

/* Responsive */
@media (max-width: 768px) {
  .content {
    grid-template-columns: 1fr; /* Một cột trên mobile */
  }

  .main-content {
    width: 100%;
    margin-left: 0;
    padding: 15px 8px;
    margin-top: 50px;
    height: calc(100vh - 50px);
  }

  .main-content-shifted {
    margin-left: 0;
    width: 100%;
  }
}

/* Column */
.column {
  background-color: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
}

.column:hover {
  transform: translateY(-2px);
}

/* Status Messages */
.loading-text {
  color: #4b5563;
  text-align: center;
  margin: 20px 0;
}

.error-text {
  color: #ef4444;
  text-align: center;
  margin: 20px 0;
}

/* Section Title */
.section-title {
  font-weight: 600;
  color: #1a3c5e;
  font-size: 16px;
  margin-bottom: 10px;
}

/* Form nhập liệu */
.huongNghienCuu,
.deTaiKHCN {
  margin-top: 15px;
}

.info-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 4px;
  padding: 4px;
}

.sub-label {
  font-weight: 600;
  color: #1a3c5e;
  font-size: 14px;
  width: 35%;
}

.input-field {
  width: 65%;
  padding: 8px;
  border: 1px solid #d1dbe3;
  border-radius: 6px;
  font-size: 14px;
  background-color: #f9fafb;
  transition: border-color 0.3s, box-shadow 0.3s, background-color 0.3s;
}

.input-field:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
  background-color: white;
  outline: none;
}

.input-field::placeholder {
  color: #a0aec0;
  font-style: italic;
}

textarea.input-field {
  resize: vertical;
  min-height: 80px;
}

/* Save Button */
.save-button {
  margin-top: 16px;
  background-color: #2563eb;
  color: white;
  padding: 8px 20px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s;
}

.save-button:hover {
  background-color: #1d4ed8;
}

.save-button:disabled {
  background-color: #93c5fd;
  cursor: not-allowed;
}

/* Danh sách hiển thị */
.list-container {
  width: 100%;
}

ol {
  padding-left: 20px;
  margin-top: 10px;
}

ol li {
  margin-bottom: 12px;
  color: #2d3748;
  font-size: 14px;
  line-height: 1.5;
  padding-left: 10px;
  position: relative;
}

ol li:before {
  content: '';
  position: absolute;
  left: 0;
  top: 8px;
  width: 5px;
  height: 5px;
  background: #2563eb;
  border-radius: 50%;
}

/* Bảng hiển thị */
.table-container {
  width: 100%;
  overflow-x: hidden; /* Không cần scroll-x */
}

table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin-top: 10px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

th,
td {
  padding: 10px 12px;
  text-align: left;
  border-bottom: 1px solid #e2e8f0;
  font-size: 13px;
}

th {
  background: #2563eb;
  color: white;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 0.5px;
}

td {
  background: #fff;
  color: #2d3748;
}

tr:last-child td {
  border-bottom: none;
}

tr:hover td {
  background: #f5faff;
}
</style>