<template>
<div class="container">
    <!-- Header -->
    <header class="header">
      <img src="@/assets/img/logo-hou.png" alt="Logo" class="logo"/>
      <h1>HỆ THỐNG QUẢN LÝ NGHIÊN CỨU KHOA HỌC</h1>

      <!-- Hiển thị trạng thái đăng nhập -->
      <div class="auth-buttons">
        <template v-if="isAuthenticated">
          <span>{{ storedEmail }}</span>
          <button @click="handleLogout">Đăng xuất</button>
        </template>

        <template v-else>
          <button @click="$router.push('/login')">Đăng nhập</button>
        </template>
      </div>
    </header>

    <!-- Main layout -->
    <div class="main-layout">
      <!-- Sidebar -->
      <SidebarManagerToNCKH class="sidebar" />

            <!-- Main content -->
            <div class="main-content">
        <div class="content">
          <h2>Quản lý sinh viên đăng ký nghiên cứu khoa học</h2>

          <!-- Thông báo trạng thái -->
          <p v-if="loading" class="loading-text">Đang tải dữ liệu...</p>
          <p v-else-if="error" class="error-text">{{ error }}</p>

          <!-- Bảng danh sách đăng ký -->
          <div v-if="!loading && !error" class="table-container">
            <table class="dangky-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Mã ĐK</th>
                  <th>Mã SV</th>
                  <th>Tên SV</th>
                  <th>Trạng Thái</th>
                  <th>Tên Giảng Viên</th>
                  <th>Hướng Nghiên Cứu</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(dangky, index) in dangKyList" :key="dangky.ma_dk">
                  <td>{{ index + 1 }}</td>
                  <td>{{ dangky.ma_dk }}</td>
                  <td>{{ dangky.ma_sv }}</td>
                  <td>{{ dangky.ten_sv }}</td>
                  <td>{{ formatTrangThai(dangky.trang_thai) }}</td>
                  <td>
                    <ul>
                      <li v-for="nv in dangky.list_nguyen_vong" :key="nv.ma_gv">
                        {{ getTenGiangVien(nv.ma_gv) }} (Ưu tiên {{ nv.muc_uu_tien }})
                      </li>
                      <li v-if="!dangky.list_nguyen_vong.length">Không có</li>
                    </ul>
                  </td>
                  <td>
                    <ul>
                      <li v-for="hnc in dangky.list_hnc" :key="hnc.ma_hnc">
                        {{ hnc.ten_hnc }}
                      </li>
                      <li v-if="!dangky.list_hnc.length">Không có</li>
                    </ul>
                  </td>
                </tr>
                <tr v-if="dangKyList.length === 0">
                  <td colspan="7">Không có dữ liệu đăng ký</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->
    <!-- <footer class="footer">
      <Footer class="footer-content" />
    </footer> -->
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import api from '@/config/api';
import SidebarManagerToNCKH from '@/components/SidebarManagerToNCKH.vue';
import Footer from '@/components/Footer.vue';

const router = useRouter();
const authStore = useAuthStore();
const { isAuthenticated, storedEmail, logout } = authStore;

// Trạng thái dữ liệu
const dangKyList = ref([]);
const giangVienList = ref([]);
const loading = ref(false);
const error = ref('');

// Kiểm tra đăng nhập và lấy dữ liệu khi mount
onMounted(() => {
  authStore.loadUserFromStorage();
  fetchGiangVienList();
  fetchDangKyList();
});

// Hàm đăng xuất
const handleLogout = () => {
  logout();
  router.push('/login');
};

// Lấy danh sách giảng viên
async function fetchGiangVienList() {
  try {
    const response = await api.get('/phongkhdn/gv/');
    const data = response.data;

    if (!Array.isArray(data)) {
      throw new Error('Dữ liệu giảng viên không hợp lệ');
    }

    giangVienList.value = data;
  } catch (err) {
    console.error('Lỗi khi lấy danh sách giảng viên:', err);
    giangVienList.value = [];
  }
}

// Ánh xạ ma_gv sang ten_gv
function getTenGiangVien(ma_gv) {
  const gv = giangVienList.value.find((g) => g.ma_gv === ma_gv);
  return gv ? gv.ten_gv : ma_gv || 'Không xác định';
}

// Lấy danh sách đăng ký từ API
async function fetchDangKyList() {
  try {
    loading.value = true;
    error.value = '';

    const response = await api.get('/tonckh/dang_ky/danh_sach');
    const data = response.data;

    if (!Array.isArray(data)) {
      throw new Error('Dữ liệu đăng ký không hợp lệ');
    }

    dangKyList.value = data.map((item) => ({
      ma_dk: item.ma_dk,
      ma_sv: item.ma_sv,
      ten_sv: item.ten_sv,
      trang_thai: item.trang_thai,
      list_nguyen_vong: (item.list_nguyen_vong || []).sort((a, b) => a.muc_uu_tien - b.muc_uu_tien),
      list_hnc: item.list_hnc || [],
    }));
  } catch (err) {
    let errorMessage = 'Không thể tải danh sách đăng ký';
    if (err.response) {
      console.error('Mã lỗi HTTP:', err.response.status);
      console.error('Chi tiết lỗi:', err.response.data);
      if (err.response.status === 401) {
        errorMessage = 'Phiên đăng nhập hết hạn';
        authStore.logout();
        router.push('/login');
      } else if (err.response.status === 403) {
        errorMessage = 'Bạn không có quyền truy cập danh sách đăng ký';
      } else if (err.response.status === 404) {
        errorMessage = 'Endpoint không tồn tại';
      } else if (err.response.status === 500) {
        errorMessage = 'Lỗi server, vui lòng thử lại sau';
      }
    } else if (err.request) {
      errorMessage = 'Không thể kết nối đến server';
    }
    error.value = errorMessage;
    dangKyList.value = [];
    console.error('Lỗi khi lấy danh sách đăng ký:', err);
  } finally {
    loading.value = false;
  }
}

// Định dạng trạng thái
function formatTrangThai(trang_thai) {
  switch (trang_thai) {
    case 1:
      return 'Đã đăng ký';
    case 2:
      return 'Đã duyệt';
    case 0:
      return 'Chưa duyệt';
    default:
      return 'Không xác định';
  }
}
</script>

<style scoped>
/* Container */
.container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  overflow-y: auto;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
}

.container::-webkit-scrollbar {
  width: 6px;
}

.container::-webkit-scrollbar-track {
  background: #e2e8f0;
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #0082c6, #0069a3);
  border-radius: 10px;
}

.container::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #0069a3, #005a8c);
}

/* Header */
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 80px;
  z-index: 1000;
  padding: 10px 20px 10px 70px;
  box-sizing: border-box;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.logo {
  width: 50px;
  margin-right: 2rem;
  margin-top: 2rem;
  transition: all 0.3s ease;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
}

.logo:hover {
  transform: scale(1.05) rotate(5deg);
  filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.2));
}

.header h1 {
  font-size: 1.2rem;
  margin: 0;
  text-align: center;
  color: #0082c6;
}

.auth-buttons {
  display: flex;
  gap: 0.8rem;
  align-items: center;
}

.auth-buttons span {
  font-size: 0.9rem;
  color: #4b5563;
  font-weight: 500;
}

.auth-buttons button {
  padding: 0.5rem 1rem;
  background: linear-gradient(135deg, #0082c6, #0069a3);
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 130, 198, 0.2);
}

.auth-buttons button:hover {
  background: linear-gradient(135deg, #0069a3, #005a8c);
  transform: translateY(-2px);
  box-shadow: 0 4px 6px rgba(0, 130, 198, 0.3);
}

/* Main layout */
.main-layout {
  display: flex;
  margin-top: 100px;
  min-height: calc(100vh - 100px - 100px);
}

/* Sidebar */
.sidebar {
  box-shadow: 4px 0 15px rgba(0, 0, 0, 0.1);
  background: linear-gradient(135deg, #0082c6, #0069a3);
  transition: all 0.3s ease;
  z-index: 999;
  width: 220px;
  position: fixed;
  top: 80px;
  left: 0;
  height: calc(100vh - 60px);
}

.sidebar ul {
  list-style: none;
  padding: 20px;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.sidebar li {
  padding: 12px 0;
  position: relative;
  transition: all 0.3s ease;
}

.sidebar li::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 1px;
  background: rgba(255, 255, 255, 0.1);
}

.sidebar li:last-child::after {
  display: none;
}

.sidebar a {
  color: #ffffff;
  text-decoration: none;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  display: block;
  padding: 10px 15px;
  border-radius: 8px;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  font-weight: 500;
}

.sidebar a::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.1);
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.sidebar a:hover {
  background: rgba(255, 255, 255, 0.15);
  transform: translateX(5px);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.sidebar a:hover::before {
  transform: translateX(0);
}

.sidebar a.router-link-active {
  background: rgba(255, 255, 255, 0.2);
  font-weight: 600;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Main Content */
.main-content {
  flex: 1;
  margin-left: 240px;
  margin-top: 20px;
  padding: 20px 40px;
  box-sizing: border-box;
  background: transparent;
  transition: all 0.3s ease;
}

/* Content */
.content {
  background-color: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  border: 1px solid rgba(226, 232, 240, 0.8);
}

.content:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.content h2 {
  font-size: 1.5rem;
  background: linear-gradient(135deg, #0082c6, #0069a3);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 1.5rem;
  font-weight: 700;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  letter-spacing: 0.5px;
}

/* Status Messages */
.loading-text {
  color: #4b5563;
  font-size: 1.1rem;
  text-align: center;
  padding: 20px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 8px;
  backdrop-filter: blur(5px);
}

.error-text {
  color: #ef4444;
  font-size: 1.1rem;
  text-align: center;
  padding: 20px;
  background: rgba(254, 226, 226, 0.8);
  border-radius: 8px;
  margin: 10px 0;
  backdrop-filter: blur(5px);
  border: 1px solid rgba(239, 68, 68, 0.2);
}

/* Table */
.table-container {
  background-color: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  overflow-x: auto;
  transition: all 0.3s ease;
  border: 1px solid rgba(226, 232, 240, 0.8);
}

.table-container:hover {
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.dangky-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin-top: 1rem;
}

.dangky-table th,
.dangky-table td {
  padding: 15px;
  text-align: left;
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
}

.dangky-table th {
  background: linear-gradient(135deg, #0082c6, #0069a3);
  color: white;
  font-weight: 600;
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  position: sticky;
  top: 0;
  z-index: 1;
}

.dangky-table td {
  background: rgba(255, 255, 255, 0.8);
  font-size: 14px;
  color: #4b5563;
  transition: all 0.3s ease;
}

.dangky-table tr:hover td {
  background: rgba(248, 250, 252, 0.8);
  transform: scale(1.01);
}

.dangky-table ul {
  margin: 0;
  padding-left: 20px;
}

.dangky-table ul li {
  font-size: 14px;
  margin-bottom: 5px;
  color: #4b5563;
  transition: all 0.3s ease;
}

.dangky-table ul li:hover {
  color: #0082c6;
  transform: translateX(5px);
}

/* Responsive */

/* Tablet (≤1024px) */
@media (max-width: 1024px) {
  .header {
    padding: 0 15px;
  }

  .main-content {
    margin-left: 220px;
    padding: 20px;
  }

  .sidebar {
    width: 200px;
  }

  .sidebar ul {
    padding: 15px;
  }

  .sidebar a {
    font-size: 13px;
    padding: 8px 12px;
  }

  .header h1 {
    font-size: 1.1rem;
  }
}

/* Mobile (≤768px) */
@media (max-width: 768px) {
  .header {
    padding: 0 10px;
    height: 60px;
    justify-content: center;
    align-items: center;
  }

  .logo {
    width: 30px;
    margin-right: 5px;
    margin-left: 40px;
  }

  .header h1 {
    font-size: 1rem;
    flex-grow: 1;
    text-align: center;
  }

  .auth-buttons {
    margin-right: 0;
    gap: 0.3rem;
  }

  .auth-buttons span {
    font-size: 0.8rem;
  }

  .auth-buttons button {
    padding: 0.3rem 0.6rem;
    font-size: 0.8rem;
  }

  .sidebar {
    width: 200px;
    left: -200px;
    top: 60px;
    height: calc(100vh - 60px);
  }

  .sidebar-open {
    left: 0;
  }

  .main-layout {
    margin-top: 80px;
  }

  .main-content {
    margin-left: 0;
    margin-top: 20px;
    padding: 15px;
  }
}

/* Small Mobile (≤480px) */
@media (max-width: 480px) {
  .header {
    padding: 0 5px;
  }

  .header h1 {
    font-size: 0.9rem;
  }

  .logo {
    width: 25px;
    margin-left: 35px;
  }

  .auth-buttons button {
    padding: 0.2rem 0.5rem;
    font-size: 0.7rem;
  }

  .sidebar {
    width: 180px;
    left: -180px;
  }

  .sidebar-open {
    left: 0;
  }

  .sidebar a {
    font-size: 12px;
    padding: 6px 10px;
  }

  .main-content {
    padding: 10px;
  }

  .content {
    padding: 15px;
  }

  .dangky-table th,
  .dangky-table td {
    padding: 10px;
    font-size: 13px;
  }

  .dangky-table ul li {
    font-size: 13px;
  }
}
</style>