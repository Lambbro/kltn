<template>
  <div class="container">
    <header class="header">
      <img src="@/assets/img/logo-hou.png" alt="Logo" class="logo" />
      <div class="button-group">
        <button class="active" @click="$router.push('/de-tai-nckh')">Tổng hợp đề tài</button>
        <button class="active" @click="$router.push('/de-tai-dang-thuc-hien')">Đề tài đang thực hiện</button>
      </div>
    </header>

    <div class="main-layout">
      <SidebarHome class="sidebar" />
      <div class="main-content">
        <div class="research-detail">
          <h2>Chi tiết đề tài</h2>
          <div v-if="research">
            <div class="research-item"> 
              <img src="@/assets/img/logo-hou.png" alt="Logo" class="research-logo" />
              <div class="research-info">
                <p><strong>Tên đề tài:</strong> {{ research.title }}</p>
                <p><strong>Người thực hiện:</strong> {{ research.researcher }}</p>
                <p><strong>Giảng viên hướng dẫn:</strong> {{ research.researcher }}</p>
                <p><strong>Năm thực hiện:</strong> {{ research.year }}</p>
                <p><strong>Giải thưởng</strong> {{ research.status }}</p>
                <p><strong>Kết quả:</strong> {{ research.result }}</p>
              </div>
            </div>
          </div>
          <div v-else>
            <p>Không tìm thấy đề tài</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import SidebarHome from '@/components/SidebarHome.vue';
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';

// Dữ liệu tĩnh (giả lập danh sách đề tài - thay bằng API nếu cần)
const researchTopics = ref([
  { id: 1, title: 'Đề tài 1', researcher: 'NgoVanSon', year: 1024, result: 'Hoàn thành' },
  { id: 2, title: 'Đề tài 2', researcher: 'NgyenQuanAnh', year: 2025, result: 'Đang thực hiện' },
  { id: 3, title: 'Đề tài 3', researcher: 'BuiAnhTuan', year: 2024, result: 'Hoàn thành' },
  { id: 4, title: 'Đề tài 1', researcher: 'NgoVanSon', year: 2024, result: 'Hoàn thành' },
  { id: 5, title: 'Đề tài 2', researcher: 'NgyenQuanAnh', year: 2025, result: 'Đang thực hiện' },
  { id: 6, title: 'Đề tài 3', researcher: 'BuiAnhTuan', year: 2024, result: 'Hoàn thành' },
  { id: 7, title: 'Đề tài 1', researcher: 'NgoVanSon', year: 2024, result: 'Hoàn thành' },
  { id: 8, title: 'Đề tài 2', researcher: 'NgyenQuanAnh', year: 2025, result: 'Đang thực hiện' },
  { id: 9, title: 'Đề tài 3', researcher: 'BuiAnhTuan', year: 2024, result: 'Hoàn thành' },
]);

// Lấy id từ URL
const route = useRoute();
const research = ref(null);

onMounted(() => {
  const id = route.params.id; // Lấy id từ URL
  research.value = researchTopics.value.find((item) => item.id == id); // Tìm đề tài theo id
});
</script>

<style scoped>
.header {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  border-bottom: 1px solid #ccc;
  background: #2563eb;
  position: fixed;
  width: 100%;
  left: 0;
  z-index: 1000;
}

.logo {
  width: 50px;
  margin-right: 5rem;
  margin-left: 80px;
}

.button-group {
  display: flex;
  gap: 20px;
  justify-content: center;
  align-items: center;
}

.button-group button {
  padding: 10px 15px;
  border: none;
  background: #e0e0e0;
  cursor: pointer;
}

.button-group .active {
  background: #2563eb;
}

.main-layout {
  display: flex;
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  margin-top: 60px;
}

.main-layout::-webkit-scrollbar {
  width: 5px;
}

.main-layout::-webkit-scrollbar-track {
  background: #e6eef5;
  border-radius: 10px;
}

.main-layout::-webkit-scrollbar-thumb {
  background: #1e88e5;
  border-radius: 10px;
}

.main-layout::-webkit-scrollbar-thumb:hover {
  background: #1565c0;
}

.sidebar {
  width: 220px;
  height: 100vh;
  background: #2563eb;
  padding-top: 20px;
  position: fixed;
  left: 0;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.main-content {
  padding: 20px;
  margin-left: 220px; /* vì sidebar đặt fixed */
  width: 100%;
}

.research-detail {
  margin-left: 20px;
  margin-right: 25px;
  width: 100%;
}

.research-item {
  display: flex;
  align-items: center;
  gap: 25px;
  padding: 15px;
  border: 1px solid #ddd;
  background: #fafafa;
  border-radius: 15px;
}

.research-logo {
  width: 85px;
  height: 100px;
}

.research-info {
  flex: 1;
  flex-basis: 60%;
}

.research-info p {
  margin: 5px 0;
}
</style>